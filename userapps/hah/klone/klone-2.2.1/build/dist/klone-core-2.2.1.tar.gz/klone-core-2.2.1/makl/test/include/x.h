#ifndef _X_H_
#define _X_H_

#include <a.h>
#include <b.h>

#endif /* !_X_H_ */
