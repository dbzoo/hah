#include <a.h>
const char *a (void) { return "Hello"; }
