#ifndef _B_H_
#define _B_H_

const char *b (void);

#endif /* !_B_H_ */

