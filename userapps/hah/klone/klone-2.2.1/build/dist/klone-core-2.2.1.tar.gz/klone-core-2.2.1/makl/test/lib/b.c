#include <b.h>
const char *b (void) { return "world"; }
