#include <stdio.h>
#include <x.h>

int main()
{
    printf("%s %s!\n", a(), b());

    return 0;
}
