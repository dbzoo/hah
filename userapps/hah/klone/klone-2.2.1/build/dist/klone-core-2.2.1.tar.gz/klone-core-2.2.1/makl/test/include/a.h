#ifndef _A_H_
#define _A_H_

const char *a (void);

#endif /* !_A_H_ */
