const char *x (void)
{
    const char *$s = "a C++ library function";
    return $s;
}
